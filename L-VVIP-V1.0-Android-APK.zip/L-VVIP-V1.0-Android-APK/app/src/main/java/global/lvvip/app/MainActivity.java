package global.lvvip.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.net.URISyntaxException;

public class MainActivity extends Activity {

    private WebView webView;
    private ProgressBar progressBar;
    private String appUrl;
    private String appHost;
    private boolean showingOfflinePage = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        appUrl = getString(R.string.app_url).trim();
        appHost = Uri.parse(appUrl).getHost();

        webView = findViewById(R.id.webView);
        progressBar = findViewById(R.id.progressBar);

        configureWebView();

        if (savedInstanceState == null) {
            loadApp();
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void configureWebView() {
        WebSettings settings = webView.getSettings();

        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            settings.setSafeBrowsingEnabled(true);
        }

        String originalUserAgent = settings.getUserAgentString();
        settings.setUserAgentString(originalUserAgent + " LVVIPApp/1.0");

        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        cookieManager.setAcceptThirdPartyCookies(webView, true);

        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);

        webView.addJavascriptInterface(new AndroidAppBridge(), "AndroidApp");
        webView.addJavascriptInterface(new AndroidShareBridge(), "AndroidShare");

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                progressBar.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }
        });

        webView.setWebViewClient(new WebViewClient() {

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                progressBar.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                progressBar.setVisibility(View.GONE);

                if (url != null && !url.startsWith("file:///android_asset/")) {
                    showingOfflinePage = false;
                    injectAndroidShareBridge(view);
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl().toString());
            }

            @Override
            public void onReceivedError(
                    WebView view,
                    WebResourceRequest request,
                    WebResourceError error
            ) {
                super.onReceivedError(view, request, error);

                if (request.isForMainFrame()) {
                    showOfflinePage();
                }
            }

        });
    }

    private void injectAndroidShareBridge(WebView view) {
        String script = "(function(){" +
                "try{" +
                "Object.defineProperty(navigator,'share',{configurable:true,value:function(d){" +
                "var t=(d&&d.title)||'';" +
                "var x=(d&&d.text)||'';" +
                "var u=(d&&d.url)||'';" +
                "AndroidShare.share(String(t),String(x),String(u));" +
                "return Promise.resolve();" +
                "}});" +
                "Object.defineProperty(navigator,'canShare',{configurable:true,value:function(){return true;}});" +
                "document.addEventListener('click',function(e){" +
                "var a=e.target&&e.target.closest?e.target.closest('a[target=\"_blank\"]'):null;" +
                "if(a&&a.href){e.preventDefault();AndroidApp.openUrl(String(a.href));}" +
                "},true);" +
                "}catch(e){}" +
                "})();";

        view.evaluateJavascript(script, null);
    }

    private boolean handleUrl(String url) {
        if (url == null || url.isBlank()) {
            return false;
        }

        Uri uri = Uri.parse(url);
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
        String host = uri.getHost();

        if (("https".equals(scheme) || "http".equals(scheme))
                && host != null
                && appHost != null
                && host.equalsIgnoreCase(appHost)) {
            return false;
        }

        if ("intent".equals(scheme)) {
            try {
                Intent intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                startActivity(intent);
                return true;
            } catch (URISyntaxException | ActivityNotFoundException e) {
                Toast.makeText(this, "找不到可開啟此連結的 App。", Toast.LENGTH_SHORT).show();
                return true;
            }
        }

        if ("http".equals(scheme)
                || "https".equals(scheme)
                || "line".equals(scheme)
                || "mailto".equals(scheme)
                || "tel".equals(scheme)) {
            openExternal(url);
            return true;
        }

        openExternal(url);
        return true;
    }

    private void openExternal(String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "手機沒有可開啟此連結的 App。", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean hasNetwork() {
        ConnectivityManager manager =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        if (manager == null) {
            return false;
        }

        Network network = manager.getActiveNetwork();
        if (network == null) {
            return false;
        }

        NetworkCapabilities caps = manager.getNetworkCapabilities(network);
        if (caps == null) {
            return false;
        }

        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
    }

    private void loadApp() {
        if (!appUrl.startsWith("https://")) {
            Toast.makeText(
                    this,
                    "請先在 strings.xml 設定正確的 HTTPS app_url。",
                    Toast.LENGTH_LONG
            ).show();
            return;
        }

        if (!hasNetwork()) {
            showOfflinePage();
            return;
        }

        showingOfflinePage = false;
        webView.loadUrl(appUrl);
    }

    private void showOfflinePage() {
        if (showingOfflinePage) {
            return;
        }

        showingOfflinePage = true;
        webView.loadUrl("file:///android_asset/offline.html");
    }

    private void shareFromAndroid(String title, String text, String url) {
        runOnUiThread(() -> {
            StringBuilder content = new StringBuilder();

            if (text != null && !text.isBlank()) {
                content.append(text.trim());
            }

            if (url != null && !url.isBlank()) {
                if (content.length() > 0) {
                    content.append("\n\n");
                }
                content.append(url.trim());
            }

            Intent sendIntent = new Intent(Intent.ACTION_SEND);
            sendIntent.setType("text/plain");
            sendIntent.putExtra(Intent.EXTRA_TEXT, content.toString());

            if (title != null && !title.isBlank()) {
                sendIntent.putExtra(Intent.EXTRA_TITLE, title);
                sendIntent.putExtra(Intent.EXTRA_SUBJECT, title);
            }

            Intent chooser = Intent.createChooser(sendIntent, "分享 L-VVIP");
            startActivity(chooser);
        });
    }

    public class AndroidShareBridge {
        @JavascriptInterface
        public void share(String title, String text, String url) {
            shareFromAndroid(title, text, url);
        }
    }

    public class AndroidAppBridge {
        @JavascriptInterface
        public void retry() {
            runOnUiThread(MainActivity.this::loadApp);
        }

        @JavascriptInterface
        public void openUrl(String url) {
            runOnUiThread(() -> handleUrl(url));
        }

        @JavascriptInterface
        public void openAppSettings() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            });
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onPause() {
        webView.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidApp");
            webView.removeJavascriptInterface("AndroidShare");
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack() && !showingOfflinePage) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
