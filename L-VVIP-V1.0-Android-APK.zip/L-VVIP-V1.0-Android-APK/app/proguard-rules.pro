# L-VVIP V1.0
# Release minification is disabled in V1.0.
