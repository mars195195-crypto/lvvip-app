# L-VVIP V1.0 Android APK

這是一個 Android WebView App 外殼，開啟線上的 `app.html` 會員工作台。

## 你只需要修改 1 個地方

開啟：

`app/src/main/res/values/strings.xml`

把：

`https://YOUR-GITHUB-PAGES-URL/app.html`

換成真正的 L-VVIP 會員工作台 HTTPS 網址。

例如：

`https://yourname.github.io/lvvip/app.html`

## GitHub 自動產生 APK

將整個專案上傳到 GitHub `main` 分支。

GitHub → Actions → `Build L-VVIP V1.0 APK`

等待完成後：

Actions → 該次成功執行 → Artifacts → `L-VVIP-V1.0-APK`

下載後即可取得：

`L-VVIP-V1.0-debug.apk`

## 功能

- 開啟線上 `app.html`
- 保留 WebView localStorage / Supabase 登入狀態
- JavaScript / DOM Storage
- Android 系統分享面板
- LINE / mail / tel / 外部網址由手機 App 開啟
- HTTPS only
- Safe Browsing
- 無網路離線提示與重新連線
- 手機返回鍵支援 WebView 歷史頁

## 目前版本

- App：1.0.0-debug
- compileSdk：37
- targetSdk：37
- minSdk：26 (Android 8.0+)
- Android Gradle Plugin：9.4.0
- Gradle：9.6.0
- Java：17

## 注意

這是測試版 Debug APK，Android 會用 Debug key 簽章，因此可以直接安裝測試。

正式公開上架 Google Play 前，應再建立 Release keystore 與正式簽章流程。
